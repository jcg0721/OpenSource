package com.example.turtle.ui.func4;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Func4ViewModel extends ViewModel {


    public Func4ViewModel() {
    }

}