import socket
import numpy as np
import cv2
from queue import Queue
from _thread import *
import time

enclosure_queue = Queue()

class PacketWriter:

    def __init__(self, length):
        self.packet = b''
        self.writeShort(length)

    def writeByte(self, value):
        self.packet += bytes([value])

    def writeShort(self, value):
        self.writeByte(value & 0xFF)
        self.writeByte((value >> 8) & 0xFF)

    def writeInt(self, value):
        self.writeByte(value & 0xFF)
        self.writeByte((value >> 8) & 0xFF)
        self.writeByte((value >> 16) & 0xFF)
        self.writeByte((value >> 24) & 0xFF)

    def writeBytes(self, value):
        self.writeShort(len(value))
        self.packet += value

    def getPacket(self):
        return self.packet

class PacketReader:

    def __init__(self, client_socket):
        self.pos = 0
        self.packet = client_socket.recv(self.getLength(client_socket))

    def getLength(self, client_socket):
        header = client_socket.recv(2)
        return header[0] + (header[1] << 8)
        ''' + (header[2] << 16) + (header[3] << 24)'''

    def readByte(self):
        value = self.packet[self.pos]
        self.pos += 1
        return value

    def readBytes(self):
        length = self.readShort()
        after = self.pos + length
        return self.packet[self.pos: after+1]

    def readShort(self):
        return self.readByte() + (self.readByte() << 8)

    def readInt(self):
        return self.readByte() + (self.readByte() << 8) + (self.readByte() << 16) + (self.readByte() << 24)

def webcam(queue):
    capture = cv2.VideoCapture(0)

    while True:
        ret, frame = capture.read()

        if ret == False:
            continue

        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]
        result, imgencode = cv2.imencode('.jpg', frame, encode_param)

        data = np.array(imgencode)
        stringData = data.tostring()

        queue.put(stringData)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

def threaded(client_socket, queue):

    while True:

        try:
            stringData = queue.get()
            pw = PacketWriter()
            pw.writeByte(0)
            pw.writeBytes(stringData)
            client_socket.send(pw.getPacket())
        except ConnectionResetError as e:

            print('Disconnected')
            break

    client_socket.close()

HOST = '203.255.81.66'
PORT = 1319

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client_socket.connect((HOST, PORT))

start_new_thread(webcam, (enclosure_queue, ))

while True:

    try:

        stringData = enclosure_queue.get()
        pw = PacketWriter(len(stringData) + 4 + 1)
        pw.writeByte(0)
        pw.writeBytes(stringData)
        client_socket.send(pw.getPacket())

    except ConnectionResetError as e:

        print('Disconnected')
        break

client_socket.close()
