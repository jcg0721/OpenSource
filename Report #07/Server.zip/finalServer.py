import socket
from _thread import *
import cv2, dlib
import numpy as np
from keras.models import load_model
from imutils import face_utils
import time


def getLength(client_socket):
    header = client_socket.recv(2)
    return header[0] + (header[1] << 8)


def threaded(client_socket):
    t = 0
    startTime = time.time()
    count = 0
    closed = False
    totalAlarm1 = 0
    totalAlarm2 = 0
    while True:
        try:
            data = client_socket.recv(4);
            if not data:
                break
            length = int.from_bytes(data, "little");
            if length == 0:
                msg = "거리 탐지 경고 횟수 : " + str(totalAlarm1);
                msg += "\n눈 깜빡임 경고 횟수 : " + str(totalAlarm2);
                if totalAlarm1 > 0:
                    msg += "\n폰을 멀리하시는게 좋을 것 같아요!"
                if totalAlarm2 > 0:
                    msg += "\n눈을 더 자주 깜빡여주세요~~!"
                data = msg.encode();
                header = 0
                length = len(data);
                client_socket.sendall(header.to_bytes(4, byteorder='little'));
                client_socket.sendall(length.to_bytes(4, byteorder='little'));
                client_socket.sendall(data);
                totalAlarm1 = 0
                totalAlarm2 = 0
                continue
            stringData = b''
            while length:
                newbuf = client_socket.recv(length)
                if not newbuf: return None
                stringData += newbuf
                length -= len(newbuf)

            data = np.frombuffer(stringData, dtype='uint8')
            img_ori = cv2.imdecode(data, 1)
            cv2.imshow('all', img_ori)
            img_ori = cv2.resize(img_ori, dsize=(0, 0), fx=0.5, fy=0.5)

            img = img_ori.copy()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            faces = detector(gray)

            for face in faces:
                shapes = predictor(gray, face)
                shapes = face_utils.shape_to_np(shapes)
                left_img, _ = crop_eye(gray, shapes[36:42])
                if left_img.shape[0] > 16 and left_img.shape[1] > 21:
                    if time.time() - t > 5:
                        msg = "폰과 눈 사이의 거리를 벌려주세요.";
                        data = msg.encode();
                        length = len(data);
                        client_socket.sendall(length.to_bytes(4, byteorder='little'));
                        client_socket.sendall(data);
                        totalAlarm1 += 1
                        t = time.time()
                left_img = cv2.resize(left_img, dsize=IMG_SIZE)
                left_input = left_img.copy().reshape((1, IMG_SIZE[1], IMG_SIZE[0], 1)).astype(np.float32) / 255.
                left_pred = model.predict(left_input)

                if left_pred > 0.9 and not closed:
                    closed = True
                    count += 1
                elif left_pred < 0.01:
                    closed = False
                if time.time() - startTime >= 60:
                    if count < 20:
                        msg = "눈을 더 자주 깜빡여주세요.";
                        data = msg.encode();
                        length = len(data);
                        client_socket.sendall(length.to_bytes(4, byteorder='little'));
                        client_socket.sendall(data);
                        totalAlarm2 += 1
                    startTime = time.time()
                    count = 0
        except:
            break

    client_socket.close()


def crop_eye(img, eye_points):  # 눈 추출
    x1, y1 = np.amin(eye_points, axis=0)
    x2, y2 = np.amax(eye_points, axis=0)
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2

    w = (x2 - x1) * 1.2
    h = w * IMG_SIZE[1] / IMG_SIZE[0]

    margin_x, margin_y = w / 2, h / 2

    min_x, min_y = int(cx - margin_x), int(cy - margin_y)
    max_x, max_y = int(cx + margin_x), int(cy + margin_y)

    eye_rect = np.rint([min_x, min_y, max_x, max_y]).astype(np.int)

    eye_img = img[eye_rect[1]:eye_rect[3], eye_rect[0]:eye_rect[2]]

    return eye_img, eye_rect


IMG_SIZE = (34, 26)

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

model = load_model('model.h5')

HOST = ''
PORT = 1319

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
while True:
    client_socket, _ = server_socket.accept()
    print('접속')
    start_new_thread(threaded, (client_socket,))

server_socket.close()